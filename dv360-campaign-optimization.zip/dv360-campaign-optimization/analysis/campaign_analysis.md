# Campaign Analysis
## Analytical Framework
Analyze performance by audience, insertion order, line item, inventory type, device, geography and channel.

### Audience
High-intent remarketing segments should be evaluated for lower CPA and stronger conversion rate. Prospecting segments should be evaluated for scalable reach and incremental conversions.

### Inventory
Compare Open Auction, PMP and Programmatic Guaranteed on CPM, viewability, conversion efficiency and predictability.

### Device
Compare Desktop, Mobile Web, Mobile App and CTV. Investigate mobile-app segments with weak conversion efficiency rather than optimizing on CTR alone.

### Video
Use VCR and viewability alongside CPM and CPA to evaluate OTT/CTV quality.

All findings must be treated as simulated because the underlying data is dummy.
