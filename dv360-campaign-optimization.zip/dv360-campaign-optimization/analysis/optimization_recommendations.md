# Optimization Recommendations
Use the framework **Observation → Action → Expected Impact**.

1. **Remarketing efficiency →** shift incremental budget to high-intent remarketing → improve blended CPA.
2. **High-CPA prospecting →** reduce bids or narrow targeting → reduce wasted spend.
3. **Weak mobile-app conversion efficiency →** review placements/inventory → improve conversion quality.
4. **High-viewability PMP →** test incremental PMP allocation → improve inventory quality where CPM is justified.
5. **Frequency pressure →** test lower exposure levels → reduce user fatigue.
6. **Strong in-market performance →** increase controlled scale → grow qualified conversions.
7. **OTT high VCR →** maintain if CPA is acceptable → preserve completed-view quality.
8. **Pacing gaps →** rebalance budgets and bids → improve delivery.
9. **Creative differences →** rotate stronger creatives and review weak variants → improve engagement.
10. **Tracking issues →** validate conversion tags/Floodlight setup → improve measurement reliability.

These are simulated recommendations, not actual Ayur Herbal actions.
