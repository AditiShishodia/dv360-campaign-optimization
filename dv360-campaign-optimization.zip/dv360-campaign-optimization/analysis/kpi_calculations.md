# KPI Calculations
- **CTR** = Clicks / Impressions × 100
- **CPM** = Spend / Impressions × 1,000
- **CPC** = Spend / Clicks
- **CPA** = Spend / Conversions
- **Conversion Rate** = Conversions / Clicks × 100
- **Viewability Rate** = Viewable Impressions / Impressions × 100
- **VCR** = Video Completions / Video Starts × 100

Use the CSV as the source for portfolio calculations. All values are simulated.
