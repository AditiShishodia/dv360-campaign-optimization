# Ayur Herbal – Simulated Campaign Performance Report
## Executive Summary
This report presents a simulated 30-day programmatic campaign and demonstrates how performance data can be translated into optimization decisions.

## Performance Snapshot
Track:
- Spend
- Impressions
- Clicks
- CTR
- CPM
- CPC
- Conversions
- CPA
- Conversion Rate
- Viewability
- VCR

## Top Performing Segments
Rank audiences, line items, inventory and devices using CPA, conversion rate and scale.

## Underperforming Segments
Identify segments with high CPA, low conversion rate or inefficient spend.

## Key Insights
Use the dataset to identify where efficiency and scale can be improved.

## Optimization Actions
Apply budget shifts, bid changes, targeting refinement, inventory exclusions, creative rotation and frequency management.

## Next Steps
Continue testing audience, inventory and creative combinations while monitoring pacing and conversion quality.

**All results are simulated and for portfolio demonstration only.**
