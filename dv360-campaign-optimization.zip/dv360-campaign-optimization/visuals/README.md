# Visuals
Recommended charts generated from the CSV:
- CPA by Audience
- CTR by Device
- Spend by Channel
- Conversions by Line Item
- Viewability by Inventory
- VCR by Video Inventory

All visual outputs should be labeled as simulated portfolio analysis.
