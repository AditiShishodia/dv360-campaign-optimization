# DV360 Campaign Structure
Advertiser → Campaign → Insertion Order → Line Item → Creative → Targeting/Inventory → Bid → Impression.

**Campaign:** business objective and overall activation context.  
**Insertion Order:** groups related buying activity with budget/pacing controls.  
**Line Item:** defines a specific buying strategy, targeting and bidding approach.  
**Creative:** ad asset and click/tracking setup.  
**Audience/Inventory:** who and where to reach.  
**Bid:** amount/strategy used in the auction.  
**Budget/Pacing:** controls planned spend and delivery.

This portfolio uses a simulated structure; exact platform controls can vary by DV360 configuration and product updates.
