# Inventory Strategy
| Factor | Open Auction | PMP | Programmatic Guaranteed |
|---|---|---|---|
| Scale | High | Medium | Lower/committed |
| Control | Lower | Higher | High |
| Pricing | Market-driven | Negotiated/variable | Agreed |
| Quality | Variable | More curated | Typically predictable |
| Predictability | Variable | Higher | High |
| Flexibility | High | Medium | Lower |

Actual availability and deal behavior depend on the publisher, deal terms and platform setup.
