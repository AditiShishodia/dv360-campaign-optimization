# Budget & Pacing
**Simulated media budget:** ₹10,00,000 over 30 days.

Monitor:
- Planned daily spend
- Actual spend
- Delivery percentage
- IO-level budget
- Line-item budgets
- Under-delivery
- Over-delivery

If an efficient line item is underfunded while another has poor CPA, consider controlled budget reallocation after checking delivery constraints and campaign goals.
