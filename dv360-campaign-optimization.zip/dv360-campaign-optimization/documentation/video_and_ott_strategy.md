# Video, OTT & CTV Strategy
Evaluate:
- CPM
- Reach
- Frequency
- Viewability
- Video Completion Rate
- CPA
- Conversion Rate

Skippable formats may trade completion rate for user choice, while non-skippable formats can produce strong completion but may carry higher costs or different reach. Optimize against the actual campaign objective rather than VCR alone.

For CTV/OTT, assess incremental reach, frequency, completion quality and downstream conversion/attribution where measurable.
