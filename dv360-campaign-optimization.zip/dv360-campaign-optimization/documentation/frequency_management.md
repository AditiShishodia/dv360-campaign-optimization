# Frequency Management
Frequency measures average exposure per user.

Monitor frequency alongside reach, CPA and conversion rate. If repeated exposure is associated with weaker response, test a lower cap or adjust targeting/inventory.

The objective is not simply the lowest frequency; it is an efficient balance between reach, repetition and conversion performance.
