# Bidding Strategy
## Manual Bidding
Provides direct control over the bid approach and can be useful when testing inventory, controlling costs or building a benchmark.

## Automated Bidding
Uses the selected optimization strategy and available signals to dynamically adjust bids toward the campaign goal.

### Interview Example
If the goal is conversion efficiency, compare CPA and conversion volume rather than judging a bidding strategy only by CTR.

Avoid assuming that an automated strategy will always improve performance; monitor delivery, cost and conversion quality.
