# Campaign QA Checklist
## Campaign Settings
- Dates
- Budget
- Pacing
- Geography
- Currency

## Targeting
- Audience
- Device
- Geography
- Inventory
- Brand safety
- Frequency

## Tracking
- Conversion tracking
- Floodlight
- Attribution
- UTM parameters

## Creatives
- Dimensions
- Click URL
- Landing page
- Approval
- Tracking

## Bidding
- Bid strategy
- Bid amount
- Optimization goal

Complete QA before launch and re-check tracking after launch.
