# Targeting Strategy
## Prospecting
Use in-market, affinity, contextual and custom audience approaches to build qualified reach.

## Remarketing
Use website visitors, product viewers and cart abandoners to capture existing intent.

## Practical Mix
- Prospecting: scale and new-user acquisition
- Remarketing: conversion efficiency
- Contextual: relevance without relying solely on audience lists
- Geography/device: control where and how users are reached

Always validate audience availability and platform-specific eligibility before activation.
