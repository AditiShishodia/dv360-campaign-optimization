# Looker Studio-Style Dashboard
## KPI Cards
Spend | Impressions | Clicks | CTR | CPM | Conversions | CPA | Viewability | VCR

## Recommended Charts
1. Spend over time — pacing and budget delivery.
2. Conversions over time — conversion trend.
3. CPA by audience — audience efficiency.
4. CTR by device — engagement comparison.
5. CPM by inventory — media cost.
6. Conversions by line item — contribution to outcomes.
7. Viewability by inventory — inventory quality.
8. VCR by video inventory — video completion quality.
9. Spend vs conversions — efficiency and scale.
10. Frequency vs conversion rate — exposure and diminishing returns.
