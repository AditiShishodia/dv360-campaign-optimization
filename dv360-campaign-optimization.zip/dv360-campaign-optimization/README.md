# DV360 Campaign Optimization – Ayur Herbal

**Programmatic Advertising | DV360 | Campaign Optimization | Performance Analysis**

> **Simulated portfolio case study using dummy data.** Ayur Herbal is used as the brand context for this portfolio exercise. The campaign structure, performance figures, insights and optimization results are illustrative and do not represent actual Ayur Herbal campaign data or performance.

## Overview
This portfolio project demonstrates a practical approach to planning, structuring, monitoring, analyzing and optimizing a simulated Display & Video 360 (DV360) campaign.

**Campaign lifecycle:** Planning → Setup → Targeting → Bidding & Budget → Launch → Monitoring → Analysis → Optimization → Reporting

## Business Objective
Drive qualified website traffic, product consideration and conversions while balancing scale, media efficiency, reach and frequency.

## Campaign Scenario
| Item | Details |
|---|---|
| Brand | Ayur Herbal |
| Industry | Beauty & Personal Care / Herbal Personal Care |
| Campaign | Ayur Herbal Digital Growth Campaign |
| Duration | 30 days |
| Simulated Media Budget | ₹10,00,000 |
| Geography | India |
| Channels | Display, Video, OTT, CTV |

## Campaign Structure
**Advertiser → Campaign → Insertion Order → Line Item → Creative → Audience/Inventory → Bid → Impression**

### Insertion Orders
1. Display Prospecting
2. Display Remarketing
3. Video Prospecting
4. OTT / CTV
5. Premium PMP Inventory

### Example Line Items
- In-Market Beauty Audience
- Affinity – Beauty & Personal Care
- Herbal & Natural Products
- Contextual Targeting
- Website Visitors
- Product Viewers
- Cart Abandoners
- Premium Display PMP
- OTT Video
- CTV Video

## Audience Strategy
- In-Market Beauty Shoppers
- Beauty & Personal Care Enthusiasts
- Herbal & Natural Product Interest
- Wellness & Personal Care
- Website Visitors
- Product Viewers
- Cart Abandoners
- Contextual Beauty Content

Prospecting builds qualified reach; remarketing focuses on users who have already shown intent.

## Inventory Strategy
The case study compares Open Auction, PMP and Programmatic Guaranteed inventory on scale, control, pricing, quality and predictability.

## Bidding, Budget & Pacing
The project evaluates manual CPM and automated bidding approaches, monitors delivery, and simulates budget reallocation toward efficient segments.

## Key KPIs
- Impressions
- Clicks
- CTR
- CPM
- CPC
- Conversions
- CPA
- Conversion Rate
- Viewability
- Video Completion Rate
- Frequency

## Optimization Approach
1. Monitor delivery and pacing.
2. Identify high- and low-performing audiences.
3. Compare CTR, CPM, CPA and conversion rate.
4. Reallocate budget toward efficient segments.
5. Refine audience targeting.
6. Manage frequency.
7. Evaluate creative and inventory performance.
8. Exclude inefficient inventory.
9. Review conversion tracking.
10. Report actionable insights.

## Optimization Case Study
The dataset intentionally contains strong, average and weak segments. A realistic workflow is to shift investment toward remarketing and high-intent audiences, review inefficient mobile-app inventory, test premium PMP inventory where viewability justifies the higher CPM, and manage frequency where performance declines.

**Any before/after improvement shown in this repository is simulated for portfolio demonstration only.**

## Dashboard
A Looker Studio-style dashboard is documented in `dashboards/dashboard_metrics.md`, with KPI cards and recommended performance views.

## Project Structure
```text
dv360-campaign-optimization/
├── README.md
├── data/dv360_campaign_data.csv
├── analysis/
├── reports/
├── dashboards/
├── documentation/
├── visuals/
└── scripts/
```

## Interview Talking Points
1. How I would structure a DV360 campaign.
2. How I select prospecting vs remarketing audiences.
3. How I compare Open Auction, PMP and PG inventory.
4. How I monitor pacing and delivery.
5. How I use frequency as an optimization lever.
6. Manual vs automated bidding.
7. How I evaluate CPA and conversion rate.
8. How I assess OTT/CTV performance.
9. How I use viewability and VCR alongside efficiency KPIs.
10. How I troubleshoot under-delivery.
11. How I perform campaign QA.
12. How I evaluate creative performance.
13. How I identify inefficient inventory.
14. How I translate reporting into optimization actions.
15. How I communicate performance insights to stakeholders.

## Tools & Skills Demonstrated
**Platforms:** DV360, Google Ads, Meta Ads  
**Analytics:** Google Analytics, Looker Studio, Excel  
**Programmatic:** DSP, SSP, Ad Server, PMP, Programmatic Guaranteed, Open Auction  
**Skills:** Campaign Setup, Media Planning, Audience Segmentation, Bidding, Budget Management, Pacing, Optimization, Performance Reporting, KPI Analysis

## Disclaimer
This is a simulated portfolio case study created using dummy data for educational and professional demonstration purposes. Ayur Herbal is used as the brand context for this portfolio exercise. No confidential client or company information has been used. This project does not claim live DV360 execution or actual Ayur Herbal campaign performance.

## About This Project
This case study demonstrates how a Programmatic & Performance Marketing Specialist can approach campaign planning, audience strategy, bidding, pacing, performance analysis and optimization using structured advertising data.
