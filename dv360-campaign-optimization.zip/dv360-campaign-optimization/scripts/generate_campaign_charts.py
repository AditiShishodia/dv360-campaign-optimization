import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
df = pd.read_csv(ROOT / "data" / "dv360_campaign_data.csv")
df["CTR"] = df["Clicks"] / df["Impressions"] * 100
df["CPA"] = df["Spend"] / df["Conversions"]
df["Viewability"] = df["Viewable_Impressions"] / df["Impressions"] * 100

out = ROOT / "visuals"
out.mkdir(exist_ok=True)

for col, metric, title, filename in [
    ("Audience","CPA","CPA by Audience","cpa_by_audience.png"),
    ("Device","CTR","CTR by Device","ctr_by_device.png"),
    ("Channel","Spend","Spend by Channel","spend_by_channel.png"),
    ("Line_Item","Conversions","Conversions by Line Item","conversions_by_line_item.png"),
    ("Inventory_Type","Viewability","Viewability by Inventory","viewability_by_inventory.png"),
]:
    s = df.groupby(col)[metric].mean() if metric in ["CPA","CTR","Viewability"] else df.groupby(col)[metric].sum()
    s.sort_values(ascending=False).plot(kind="bar", figsize=(10,5))
    plt.title(title)
    plt.ylabel(metric)
    plt.tight_layout()
    plt.savefig(out / filename, dpi=160)
    plt.close()
